﻿#include <iostream>
#include <algorithm>
using namespace std;
int n, m;
int s[1000][1000]; /*Mảng để quy hoach động - Khai báo biến toàn cục các phần tử sẽ = 0 hết
(Nếu khai báo biến  mảng trong hàm thì khi quy hoạch động cần khởi tại hàng 0 và cột 0 có giá trị là 0 nhé) */

//Hàm tìm độ dài xâu con chung lớn nhất
int dodaixauchung(string a, string b)
{
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
        {
            //áp dụng công thức truy hồi
            if (a[i - 1] == b[j - 1]) s[i][j] = s[i - 1][j - 1] + 1;
            else s[i][j] = max(s[i - 1][j], s[i][j - 1]);
        }
    return s[n][m];
}

//Hàm truy vết lấy ra xâu con chung đó
string lanvet(string a)
{
    string xauchung = "";
    int t = 0;

    //TRuy vết theo đúng ý tưởng trên
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            if (s[i][j] > t)
            {
                t = s[i][j];
                xauchung += a[i - 1];
            }
    return xauchung; //Trả về xau con
}
int main()
{
    string a = "BACDB";
    string b = "BDCB";
    n = a.length(); m = b.length();
    cout << "Do dai xau chung: " << dodaixauchung(a, b); //In ra độ dài xâu con
    cout << "\nXau chung: " << lanvet(a); //In ra xâu con đó
    return 0;
}